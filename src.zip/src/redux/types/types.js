export const typesProducts = {
   add: "add",
   list: "list",
   edit: "edit",
   delete: "delete",
};

export const typesLogin = {
   login: "login",
   logout: "logout",
   register: "register",
};
