import React from 'react'
import "../styles/styles.css"
const Buscador = () => {
    return (
        <div>

            <div>
                <form className="form">
                    <div className="busqueda">
                        <input type="search" name="search" className="search" placeholder="Search for ..." />
                    </div>
                </form>
            </div>


        </div>
    )
}

export default Buscador